package com.qualizeal.task;

import java.util.Scanner;

public class MainClass {
    public static void main(String[] args) {


        FootballTeams[] teams = new FootballTeams[3];
        System.out.println("Enter No team" );

        for (int i = 0; i < teams.length; i++) {
            System.out.println("Enter details for Team " + (i + 1));
            teams[i] = new FootballTeams();
            teams[i].getTeamDetails();
        }


        FootballTeams footballTeams = new FootballTeams();
        footballTeams.displayTeamDetails(teams);
    }


    }



