package com.qualizeal.task;

import javax.xml.namespace.QName;
import java.util.Scanner;

public class FootballTeams {
   public  String arr[];
   public  String bench[];
   public String coach;
   public String Manager;


    Scanner sc = new Scanner(System.in);

    void displayTeamDetails(FootballTeams[] teams) {
        for (int i = 0; i < teams.length; i++) {
            System.out.println("Team " + (i + 1) + " Details:");
            System.out.println("Players:");
            for (String player : teams[i].arr) {
                System.out.println(player);
            }
            System.out.println("Bench:");
            for (String player : teams[i].bench) {
                System.out.println(player);
            }
            System.out.println("Coach: " + teams[i].coach);
            System.out.println("Manager: " + teams[i].Manager);
            System.out.println();
        }
    }

    void getTeamDetails(){
        System.out.println("Enter coach:");
        coach = sc.nextLine();
        System.out.println("Enter manager:");
        Manager = sc.nextLine();
        System.out.println("Enter players for team");
        arr = sc.nextLine().split(",");
        System.out.println("Enter bench players for team ");
        bench = sc.nextLine().split(",");


}
}

